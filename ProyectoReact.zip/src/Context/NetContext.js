import React from "react";

const NetContext = React.createContext({});

export default NetContext;